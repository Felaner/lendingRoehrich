// module.exports = {
//     BASE_URL:
//     HOST:
//     DATABASE_USER:
//     DATABASE_PASS:
//     DATABASE_NAME:
//     EMAIL_USER:
//     EMAIL_PASS:
//     EMAIL_HOST:
// }
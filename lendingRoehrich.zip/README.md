"# Trener" 
